// ✍️ Envio de história via Airtable
document.addEventListener('DOMContentLoaded'), function () {
};
